# This file is part of the standard testthat testing framework
library(testthat)
library(gerda)

test_check("gerda")
